Example project for setting up a BepinEx plugin to connect a game to crowd control

Instructions

1) Update References  
	Update BepinEx references to point to the BepinEx.dll from the downloaded version of BepinEx  
	Add a reference to Assembly-CSharp from the game's data folders  

2) Create Effect List  
	ControlClient.cs initializes a dictionary called 'Delegate' which connects effect codes to functions  

3) Create Effect Functions  
	CrowdDelegates.cs contains the functions implementing effects, see the examples there for how to implement  

4) Create Timed Effects  
	Timed effects work similarly to normal effects, but besides their start code in CrowdDelegates.cs their behavior must be defined in TimedEffects.cs  
	And they use an identifier also specified in TimedEffects.cs to perform their behviors in the addEffect, removeEffect, and tick functions there  

5) Setup isReady Function  
	ControlClient.cs contains a function called isReady which returns a boolean indicating whether the game is in a state ready to execute effects  
	This is not strictly necessary, but it will auto retry effects for you and timed effects will pause and resume if this function is filled  

6) Attach Action Queue  
	Some game code will not be runnable directly from the plugin and needs to run in the Unity code loop  
	In Main.cs there is an example harmony patch to attach to the update() function of some universal object  

ControlClient offers a few helper functions for hiding or disabling effects  
	HideEffect(string code)  
	ShowEffect(string code)  
	EnableEffect(string code)  
	DisableEffect(string code)  
